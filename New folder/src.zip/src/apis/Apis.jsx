
 export const Base_Url= 'https://tekisky-mart.onrender.com';

//  APIS

 export const getAllProductAPI="/admin/getproduct";
 export const saveOrderProductAPI="/order/saveOrder";
 export const AllOrderAPI="/order/getAllOrders";

