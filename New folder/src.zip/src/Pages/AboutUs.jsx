import React from 'react'
import "../Assets/Styles/AboutUs.css"
const AboutUs = () => {
  return (
    <>
         <div className="first-image-container">
        <h2 className="first-container-heading">ABOUT US</h2>
      </div>
    </>
  )
}

export default AboutUs