import React from "react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

const Testimonials = () => {
  return (
    <div className="c-tesimonals">
      <h3>Tesimonals</h3>
      <div className="main-tesimonals">
        <Row>
          <Col xs={12} md={6} xl={6}>
            <div></div>
          </Col>
          <Col xs={12} md={6} xl={6}>
            <div></div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default Testimonials;
